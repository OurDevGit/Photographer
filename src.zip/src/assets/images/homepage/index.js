
export { default as TriaRect } from './triangle-rect.svg'
export { default as TriaRectSmall } from './triangle-rect-small.svg'
export { default as BglinesPng } from './bg_lines.jpg'

export { default as AvatarDefault } from './Avatar_default.jpg'
