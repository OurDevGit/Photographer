import { globalSaga } from './global'

export default [
  globalSaga,
]
