export { default } from './PanAndZoomImage'
