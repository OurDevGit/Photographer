const config = {
  intercomAppId : 'zvhi5494',
  sentryDSN     : 'https://3423460fdddc4022b7e41493c4fe9dda@sentry.io/1813639',
  gaTrackingId  : 'UA-133423124-1',
}

export default config
